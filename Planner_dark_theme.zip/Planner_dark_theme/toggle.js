while(document.getElementById("my-custom-dark-style"))
{
    document.getElementById("my-custom-dark-style").remove()
}
